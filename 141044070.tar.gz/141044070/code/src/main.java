import java.io.File;
import java.util.Scanner;

/**
 * Created by oem on 16.05.2017.
 */
public class main {

    public static  void main(String args[]) throws Exception{
        File file = new File("ExampleIGraphInputOrOutputFile.txt");
        Scanner scan = new Scanner(file);

        ListGraph obj = (ListGraph) AbstractGraph.createGraph(scan,false,"List");

       // System.out.println(obj.isBipartiteUndirectedGraph());
        //obj.breadthFirstSearch(0);
        obj.writeGraphToFile("x.txt");
       // obj.addRandomEdgesToGraph(5);
       // obj.writeGraphToFile("x.txt");




        /*
         getComponent testi
        File file = new File("ExampleIGraphInputOrOutputFile2.txt");
        Scanner scan = new Scanner(file);

        ListGraph obj = (ListGraph) AbstractGraph.createGraph(scan,false,"List");
       MatrixGraph []a = (MatrixGraph[]) obj.getConnectedComponentUndirectedGraph();
       for (int i=0;i<a.length;i++){
           a[i].writeGraphToFile(String.valueOf(i)+"txt");
       }
        System.out.println(obj.getNumV());
    */






    }
}
