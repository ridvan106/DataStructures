import com.sun.org.apache.xpath.internal.operations.Bool;

import java.io.File;
import java.io.FileWriter;
import java.util.*;

/**
 * Created by Rıdvan Demirci 141044070
 */
public class AbstractGraphExtended extends AbstractGraph {
    private String data = "";
    private boolean[] writeIdentified = new boolean[super.getNumV()];

    /**
     * write methodu için oluşturulan ArrayList source
     */
    private ArrayList<Integer> source2;
    /**
     * write methodu için oluşturulan ArrayList destinatiın
     */
    private ArrayList<Integer> destination2;

    private ArrayList<MatrixGraph> graf = new ArrayList<MatrixGraph>();
    /**
     * componentlar için oluşturulan ArrayList
     */
    private boolean[] Componentidentified = new boolean[super.getNumV()];

    /**
     * constructure
     * @param numV vertex sayısı
     * @param directed true or false
     */
    public AbstractGraphExtended(int numV, boolean directed) {
        super(numV, directed);
    }

    /**
     * gelen ekleme limiti ile raskele sayı belirleyip ekler
     * zaten var ise eklemez ve sayaç artmaz
     *
     * @param edgeLimit eklenecek olan edge Limiti
     * @return
     */
    public int addRandomEdgesToGraph (int edgeLimit) {

        Random adet =  new Random();
        int sayac =0;
        int HowManyEdge = Math.abs(adet.nextInt(edgeLimit));
        for (int i=0;i<HowManyEdge;i++){
            int source = Math.abs(adet.nextInt()) % super.getNumV();
            int destination = Math.abs(adet.nextInt()) % super.getNumV();

            if(!isEdge(source,destination) && !isEdge(destination,source)){
                Edge temp = new Edge(source,destination,1);
                sayac++;
                /**
                 * source ve destinationa ekleme
                 */
                insert(temp);
                /**
                 * directed ise tesine de eklenir
                 */
                if(!isDirected()){
                    Edge temp2 = new Edge(destination,source,1);
                    insert(temp2);
                }
            }
        }

        return sayac;
    }

    /**
     * method kitapdan aldım sadece staticleri değiştirdim ve dolaşırken
     * current ve neigbord degerlerini arrayListe attım
     *
     * @param start başlangıç vertex
     * @return parentları
     */

    public int [] breadthFirstSearch (int start){
         ArrayList<Integer> source = new ArrayList<Integer>();
         ArrayList<Integer> destination = new ArrayList<Integer>();

        Queue< Integer > theQueue = new LinkedList< Integer >();
        // Declare array parent and initialize its elements to 1.
        int[] parent = new int[super.getNumV()];
        for (int i = 0; i < super.getNumV(); i++) {
            parent[i] = -1;
        }
        // Declare array identified and
        // initialize its elements to false.
        boolean[] identified = new boolean[super.getNumV()];
    /* Mark the start vertex as identified and insert it
       into the queue */
        identified[start] = true;
        writeIdentified[start] = true;
        theQueue.offer(start);

    /* While the queue is not empty */
        while (!theQueue.isEmpty()) {
      /* Take a vertex, current, out of the queue.
       (Begin visiting current). */
            int current = theQueue.remove();


      /* Examine each vertex, neighbor, adjacent to current. */

            Iterator < Edge > itr = edgeIterator(current);

            while (itr.hasNext()) {

                Edge edge = itr.next();
                int neighbor = edge.getDest();

                /* ikililer kumeye eklenir */
                 source.add(current);
                destination.add(neighbor);
                /*  *   *   *   *   *   *   */

                // If neighbor has not been identified
                if (!identified[neighbor]) {


                    // Mark it identified.
                    identified[neighbor] = true;
                    writeIdentified[neighbor] = true;
                    // Place it into the queue.
                    theQueue.offer(neighbor);
          /* Insert the edge (current, neighbor)
             into the tree. */
                    parent[neighbor] = current;

                }
            }
            // Finished visiting current.
        }
        source2 = source;
        destination2 = destination;


        return parent;

    }

    /**
     * graphı verilen format ile dosyaya yazar
     *
     * @param fileName
     */

    public void writeGraphToFile (String fileName){
        data = "";

        File file = new File(fileName);

        try  {


            breadthFirstSearch(0);
            int i=0;
                //System.out.println(source.toString());
                //System.out.println(destination.toString());
            if(!isDirected()) {
                while (i < source2.size()) {
                    int target = source2.get(i);
                    int j = i + 1;
                    while (j < destination2.size()) {
                        if (target == destination2.get(j)) {
                            source2.remove(j);
                            destination2.remove(j);

                        }
                        j++;

                    }
                    i++;
                }
            }
                i=0;
                while(i< source2.size()){
                    int src = source2.get(i);
                    int target = destination2.get(i);

                    for (int j=i+1;j<source2.size();j++){
                        if(src == source2.get(j) && target == destination2.get(j)){
                            source2.remove(j);
                            destination2.remove(j);
                            break;
                        }
                    }
                    i++;

                }
              System.out.println(source2.toString());
            System.out.println(destination2.toString());
            data += super.getNumV()+"\n";
            for (i=0;i<source2.size();i++){
                data += source2.get(i) +" "+ destination2.get(i)+"\n";
            }

            for (int a=0;a<getNumV();a++){
                if(writeIdentified[a] == false){
                    helpwriteGraphToFile(a);
                }
            }



            FileWriter write = new FileWriter(file);


            write.write(data);


            write.close();
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }




    }

    /**
     * tüm graphları yazması için helper write methodu
     * @param start
     */
    private void helpwriteGraphToFile (int start){

        breadthFirstSearch(start);
        int i=0;
        //System.out.println(source.toString());
        //System.out.println(destination.toString());
        if(!isDirected()) {
            while (i < source2.size()) {
                int target = source2.get(i);
                int j = i + 1;
                while (j < destination2.size()) {
                    if (target == destination2.get(j)) {
                        source2.remove(j);
                        destination2.remove(j);

                    }
                    j++;

                }
                i++;
            }
        }
        i=0;
        while(i< source2.size()){
            int src = source2.get(i);
            int target = destination2.get(i);

            for (int j=i+1;j<source2.size();j++){
                if(src == source2.get(j) && target == destination2.get(j)){
                    source2.remove(j);
                    destination2.remove(j);
                    break;
                }
            }
            i++;

        }
        System.out.println(source2.toString());
        System.out.println(destination2.toString());


        for (i=0;i<source2.size();i++){
            data += source2.get(i) +" "+ destination2.get(i)+"\n";
        }


    }


    /**
     * graphı breadFirstSearch ile tarar ve en son idenfied tablosuna akar
     * false var ise tekrar oradan devam eder
     *
     * @return graph arrayi döndürür
     */

    public Graph [] getConnectedComponentUndirectedGraph () {
        if(isDirected()){
            System.out.println("Graph unDirected olmalı");
            return null;
        }
        ArrayList<Edge> tempEdge = new ArrayList<Edge>();


        Queue<Integer> theQueue = new LinkedList<Integer>();
        // Declare array parent and initialize its elements to 1.
        int[] parent = new int[super.getNumV()];
        for (int i = 0; i < super.getNumV(); i++) {
            parent[i] = -1;
        }
        int start = 0;
        // Declare array identified and
        // initialize its elements to false.

    /* Mark the start vertex as identified and insert it
       into the queue */
        Componentidentified[start] = true;
        theQueue.offer(start);

    /* While the queue is not empty */
        while (!theQueue.isEmpty()) {
      /* Take a vertex, current, out of the queue.
       (Begin visiting current). */
            int current = theQueue.remove();


      /* Examine each vertex, neighbor, adjacent to current. */

            Iterator<Edge> itr = edgeIterator(current);

            while (itr.hasNext()) {

                Edge edge = itr.next();
                int neighbor = edge.getDest();
                System.out.println(current +"-" + neighbor);
                Edge T = new Edge(current,neighbor,1);
                tempEdge.add(T);
                // If neighbor has not been identified
                if (!Componentidentified[neighbor]) {


                    // Mark it identified.
                    Componentidentified[neighbor] = true;
                    // Place it into the queue.
                    theQueue.offer(neighbor);
          /* Insert the edge (current, neighbor)
             into the tree. */
                    parent[neighbor] = current;

                }
            }
            // Finished visiting current.


        }
        MatrixGraph s = new MatrixGraph(tempEdge.size(),isDirected());
        for (int a =0;a < tempEdge.size();a++){
            s.insert(tempEdge.get(a));
        }
        graf.add(s);

        int counter =1;

        for (int a=0;a<getNumV();a++){
            if(Componentidentified[a] == false){
                counter++;
                System.out.print(a);
                helpComponent(a);
            }
        }
        /**
         * Return kısmını ayarlamak içim kullanılır
         */
        MatrixGraph [] temp = new MatrixGraph[graf.size()];
        for (int i=0;i<graf.size();i++){
            temp[i] = graf.get(i);
        }
        /** *   *   *   *   *   *   *   *   *       **/
        System.out.println("graf sayısı: "+counter);
        return temp;
    }

    /**
     * idenfiead tablosunda false var ise ordan aldıgı deger ile
     * breadFirst search yapar componen help fonksyonu
     * @param start
     */

    private void helpComponent(int start){
        System.out.println("New Component");
        ArrayList<Edge> tempEdge = new ArrayList<Edge>();
        Map<Integer,Integer> orginal = new HashMap<Integer,Integer>();

        Queue<Integer> theQueue = new LinkedList<Integer>();
        // Declare array parent and initialize its elements to 1.

        // Declare array identified and
        // initialize its elements to false.
    /* Mark the start vertex as identified and insert it
       into the queue */
        theQueue.offer(start);
        int current1 = 0;
        int neighbord1 = 0;

    /* While the queue is not empty */
        while (!theQueue.isEmpty()) {
      /* Take a vertex, current, out of the queue.
       (Begin visiting current). */
            int current = theQueue.remove();
            Componentidentified[current]  =true;
            if(!orginal.containsKey(current)){
                orginal.put(current,current1++);
            }


      /* Examine each vertex, neighbor, adjacent to current. */

            Iterator<Edge> itr = edgeIterator(current);

            while (itr.hasNext()) {

                Edge edge = itr.next();
                int neighbor = edge.getDest();
               // System.out.println(neighbor);
               if(Componentidentified[neighbor]!=true) {
                    Componentidentified[neighbor] = true;

                        theQueue.offer(neighbor);




               }
                if (!orginal.containsKey(neighbor)) {
                    orginal.put(neighbor, current1++);
                }

                Edge T = new Edge(orginal.get(current), orginal.get(neighbor), 1);


                tempEdge.add(T);


                // If neighbor has not been identified

                }
            }
        if(tempEdge.size() != 0) {
            MatrixGraph s = new MatrixGraph(orginal.size(),isDirected());

            for (int a = 0; a <tempEdge.size(); a++) {
                System.out.println(tempEdge.get(a).getSource() + "-" + tempEdge.get(a).getDest());
                s.insert(tempEdge.get(a));
            }


            s.writeGraphToFile("x.txt");
            graf.add(s);
            // Finished visiting current.

        }
        }

    /**
     *  Derste anlatılan format ile yaptım kendi true ise komşuları false olur
     *  en son komşu karşılaştırılması yapılır
     * @return true or false
     */
    public boolean isBipartiteUndirectedGraph (){
        if(isDirected()){
            System.out.println("Directed degil");
            return false;
        }
        boolean[] identified = new boolean[super.getNumV()];
        ArrayList<Boolean> table = new ArrayList<Boolean>(getNumV());
        for (int i=0;i<getNumV();i++)
            table.add(i,false);


        Queue< Integer > theQueue = new LinkedList< Integer >();
        int start = 0;
        theQueue.offer(start);
        identified[start] = true;
        table.set(start,true);
        // Declare array parent and initialize its elements to 1.


    /* While the queue is not empty */
        while (!theQueue.isEmpty()) {
            int current = theQueue.remove();
            boolean next = !table.get(current);

            Iterator<Edge> itr = edgeIterator(current);

            while (itr.hasNext()) {

                Edge edge = itr.next();
                int neighbor = edge.getDest();
                if(identified[neighbor] ==false) {
                    identified[neighbor] = true;
                    table.set(neighbor, next);
                    theQueue.offer(neighbor);
                }

            }
        }
        start =0;
        for(int i=0;i< getNumV();i++){
            Iterator<Edge> itr = this.edgeIterator(i);

            while(itr.hasNext()){
                Edge neigbor = itr.next();
                boolean U = table.get(neigbor.getSource());
                boolean V = table.get(neigbor.getDest());
                if(U == V)
                    return false;



            }

        }


        return true;



        }




    @Override
    public void insert(Edge edge) {

    }

    @Override
    public boolean isEdge(int source, int dest) {
        return false;
    }

    @Override
    public Edge getEdge(int source, int dest) {
        return null;
    }

    @Override
    public Iterator<Edge> edgeIterator(int source) {
        return null;
    }
}
