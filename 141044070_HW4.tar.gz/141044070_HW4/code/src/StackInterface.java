
/**
 * olusturulacak Stack için inteface
 * @author Rıdvan Demirci 141044070
 * @param <E> olusturulacak 
 */
public interface StackInterface<E> {
    public void push(E data);
    public E pop();
    public boolean isEmpty();
    public int size();
}
