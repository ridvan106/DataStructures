
import java.util.LinkedList;


/**
 * Linked list composition olarak kullanılır
 * @author Rıdvan Demirci 141044070
 * @param <E>
 */
public class PriorityQueueB<E> {
    /**
     * private linkedlist
     */
    private LinkedList<E> data =new LinkedList<>();
    
    /**
     * linked liste ekler
     * @param data verilen data
     */
    public void insert(E data){
       this.data.add(data);        
    }
    /**
     * boş olup olmama durumu
     * @return true or false
     */
    public boolean isEmpty(){
       return  data.isEmpty();       
    }
    /**
     * 
     * @return kaç eleman var ise
     */
     public int size(){
        return data.size();        
    }
     /**
      * En kucuk elemanı siler
      * @return en kucuk eleman
      */
      public E deleteMin(){

        int i;
        int indis = 0;
        E min = data.get(indis);
        for (i= 0; i < size(); i++) {
            // Stringin compare Methodundan faydalanılır
            if( data.get(i).toString().compareTo(min.toString()) < 0){
                indis = i;
                min = data.get(indis);
                
            }
        }
        
        data.remove(indis);
        return min;
        
    }
    
    
}
