

import java.util.Queue;

/**
 * implement myQueue extends KWLinledList
 * @author Rıdvan Demirci 141044070
 * @param <E> Generic
 */
@SuppressWarnings("unchecked")

public class myQueue<E> extends KWLinkedList<E>{
    /**
     * 
     * @param item gereken Data eklenir
     * @return true or false
     */
   public boolean offer(E item){
       
        this.listIterator().add(item);
        return true;
    }
   /**
    * Quenun en öndeki veri return edilir ve silinir
    * @return  en çndeki veri 
    */
   public E remove(){
       return super.removee();
   }
   /**
    * En öndeki veri return edilir ve silinir
    * veri yoksa null return eder
    * @return En öndeki veri
    */
   public E poll(){
       if(super.size() == 0)
           return null;
       else{
           return super.removee();
       }
   }
   /**
    * Sadece en öndeki veriyi return eder Queue nun başındaki elemanı
    * @return  En öndeki eleman
    */
   public E peek(){
       return getLast();
   }
   /**
    * 
    * @return Queuenun eleman sayısı
    */
   @Override
   public int size(){
       return super.size();
   }
   /**
    * 
    * @return Queuenun başındaki eleman 
    */
    public E element(){
        return this.getLast();
    }
    /**
     * myQueue daki veriler helper funktion ile reverse edilir
     */
    public void reverse(){
       helperReverse(this);
    }
    /**
     * Queue objesi alır ve ters çevirir
     * @param temp Queue objesi alır
     */
    public  void reverseQueue(Queue<E> temp){
           if(temp.size() == 0){
               // nothing
           }else{
               E te = temp.remove();
               reverseQueue(temp);
               temp.offer(te);
           }
        
        
    }
    /**
     * myQueue alır  ve ters çevirir helper ve recursive
     * @param temp myQueue alır 
     */

    private void helperReverse(myQueue<E> temp) {
           if(temp.size() == 0){
               
           }else{
               E te = temp.poll();
               helperReverse(temp);
               temp.offer(te);
           }
    
    }
}
