
import java.util.ArrayDeque;
import java.util.Queue;



/**
 *Queue composition olarak kullanılır
 * @author Rıdvan Demirci 141044070
 * @param <E>
 */
@SuppressWarnings("unchecked")
public class StackD<E> implements StackInterface<E>{
    private Queue<E> data = new ArrayDeque<>();
    private int size;
    public StackD(){
        size = 0;
                
        
    }
     /**
     * Stackin sonuna eleman ekler
     * @param data eklenecek olan veri
     */
    @Override
    public void push(E data) {
        this.data.offer(data);
        size++;
         }

     /**
     * Stackin sonundan Eleman cikarir
     * @return  Son elemanı return eder
     */
    @Override
    public E pop() {
        if(size == 0){
            throw new IndexOutOfBoundsException("Pop olmaz Size 0 'dır Exception"
                    + " fırlatıldı");
        }
                
        return getLastandRemove();
    }

     /**
     * Bos olup olmadıgı kontrol edilir
     * @return  true or false
     */
    @Override
    public boolean isEmpty() {
        return (size == 0);
    }

    /**
     * 
     * @return Stack Size
     */
    @Override
    public int size() {
        return size;
    }
    /**
     * Son elemanı silmek için helper method
     * @return  Son elemanı return eder
     */
    private E getLastandRemove(){
        Queue<E> temp = new ArrayDeque<>();
        for (int i = 0; i < size-1 ; i++) {
            temp.offer(data.poll());
        }
        size--;
        for (int i = 0; i < size ; i++) {
            data.offer(temp.poll());
        }
        E returnVal = data.poll();
        return returnVal;
        
        
    }
    
}
