
import java.util.ArrayList;

/**
 *Arraylist extends edilerek kullanılır
 * @author Rıdvan Demirci 141044070
 * 
 * @param <E>
 */
@SuppressWarnings("unchecked")
public class StackA<E> extends ArrayList implements StackInterface<E>{
    /**
     * stack Size
     */
    private int size;
    /**
     * default constructure size= 0
     */
    public StackA(){
        this.size = 0;
    
}
    /**
     * en sona eleman eklenir
     * @param data 
     */
    @Override
    public void push(E data) {
        this.add(data);
        size++;
    }

    /**
     * en sonki eleman cikarilir
     * @return 
     */
    @Override
    public E pop() {
        if(size == 0){
            throw new IndexOutOfBoundsException("Pop olmaz Size 0 'dır Exception"
                    + " fırlatıldı");
        }
        E temp = (E)this.get(size-1);
        this.remove(--size);
        return temp;
    }

    /**
     * stack classındaki size 
     * @return 
     */
    @Override
    public boolean isEmpty() {
      return size() == 0;
    }

    /**
     * suanki size return edilir
     * @return 
     */
    @Override
    public int size() {
        return this.size;
    }
    
    
}
