

/**
 *
 * @author Rıdvan Demirci 141044070
 */
public class Soru3Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{


        soru3test t = new soru3test();
        t.test();


    }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    
}
}
