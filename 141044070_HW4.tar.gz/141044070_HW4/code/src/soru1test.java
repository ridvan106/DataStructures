
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;


/**
 * 4 farklı Stack türü için  dosyadan degerleri okur
 * ve testResult_1.csv dosyasına yazar başınada size koyar
 * @author Rıdvan Demirci 141044070
 */
@SuppressWarnings("unchecked")
public class soru1test {
    
    /**
     * test etmek icin method
     * degiskenler dongude olsur hersatır icin ve dosyaya yazar
     */
    public void test(){
         try{
            
        File fp = new File("test.csv");
        Scanner fileScanner = new  Scanner(fp);
        File Writefp = new File("testResult_1.csv");
        FileWriter fwrite = new FileWriter(Writefp);
        BufferedWriter bfwriter = new BufferedWriter(fwrite);
        
        
        
        while(fileScanner.hasNextLine()){
        StackA a = new StackA();// Stacklerin olusması
        StackB b = new StackB();
        StackC c = new StackC();
        StackD d = new StackD();
        String [] temp = fileScanner.nextLine().split(",");
            for (int i = 0; i < temp.length; i++) {
                a.push(temp[i]);    // satırların stacklere push edilmesi
                b.push(temp[i]);
                c.push(temp[i]);
                d.push(temp[i]);
               
            }
            Integer temp1 = a.size();// Stackin size ve içindekileri dosyaya pop etme
            //System.out.println(temp1.toString());
           bfwriter.append(temp1.toString());
            int loop = a.size();
            while(a.size( )> 0){
                bfwriter.append(","+a.pop());
                
            }
           
            
            temp1 = b.size();
            bfwriter.append("\n"+temp1.toString());
            while(b.size( )> 0){
                bfwriter.append(","+b.pop());
                
            }
                      
            
            temp1 = c.size();
            bfwriter.append("\n"+temp1.toString());
           while(c.size( )> 0){
                bfwriter.append(","+c.pop());
                
            }
           
           
           
             temp1 = d.size();
            bfwriter.append("\n"+temp1.toString());
            while(d.size( )> 0){
                bfwriter.append(","+d.pop());
                
            }
              
            bfwriter.append("\n");
            
        
        }
      bfwriter.close();
      fwrite.close();
    }
    
    catch(Exception e){
        System.out.println(e.getMessage());
        }
    }
    
}
