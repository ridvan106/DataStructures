
/**
 *
 * @author Rıdvan Demirci 141044070
 */
@SuppressWarnings("unchecked")
public class Soru1Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       soru1test t = new soru1test();


        t.test();

    
    }
  
}
