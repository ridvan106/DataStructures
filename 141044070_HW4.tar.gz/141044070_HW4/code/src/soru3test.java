
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

/**
 *
 * @author Rıdvan Demirci 141044070
 */
public class soru3test {
    /**
     * test.csv den satırları okur ve her 2 queue da da
     * deletemin ile tekrar result 3 e ekler sıralı bir biçimde
     */
    public void test(){
        try{
         File fp = new File("test.csv");
            Scanner fileScanner = new  Scanner(fp);
            File Writefp = new File("testResult_3.csv");
            FileWriter fwrite = new FileWriter(Writefp);
            BufferedWriter bfwriter = new BufferedWriter(fwrite);
             while(fileScanner.hasNextLine()){
                 PriorityQueueA queA = new PriorityQueueA();
                 PriorityQueueB queB = new PriorityQueueB();
                 // virgüle gore parçalama
                 String [] temp = fileScanner.nextLine().split(",");
                 for (int i = 0; i < temp.length; i++) {
                        queA.insert(temp[i]);
                        queB.insert(temp[i]);
               
                }
                 // resulta ekleme
                while(queA.size( ) > 0){
                    bfwriter.append(","+queA.deleteMin());
                
                }
                bfwriter.append("\n");
                while(queB.size( ) > 0){
                    bfwriter.append(","+queB.deleteMin());
                
            }
                 bfwriter.append("\n");
                 
             }
             
             bfwriter.close();
             fwrite.close();
            
            
            
         }catch(Exception E){
             System.out.println(E.getMessage());
         }
}
}
