
import java.util.LinkedList;

/**
 * Linkedlist extends edilerek kullanılır
 * @author Rıdvan Demici 141044070
 */
public class PriorityQueueA<E> extends LinkedList<E>{
    
    /**
     * listeye veriyi ekler
     * @param data  verilen data
     */
    public void insert(E data){
        super.add(data);
        
        
    }
   /**
    * Listedeki minumum degeri siler
    * @return silinen kucuk degeri return eder
    */
    public E deleteMin(){

        int i;
        int indis = 0;
        indis = 0;
            E  minn = (get(indis));
            for (i= 0; i < super.size(); i++) {
            // Stringin compareTo methodundan yararlanılır
            
            if( super.get(i).toString().compareTo(minn.toString()) < 0){
                indis = i;
                minn = super.get(indis);
                
            }
        }
        E t = remove(indis);
        return t;

    
        
        
    }
    /**
     * Boş olup olmamasını return eder
     * @return true or false
     */
    @Override
    public boolean isEmpty(){
       return  super.isEmpty();
        
        
    }
    
    /**
     * 
     * @return size
     */
    @Override
    public int size(){
        return super.size();
        
    }
    
}
