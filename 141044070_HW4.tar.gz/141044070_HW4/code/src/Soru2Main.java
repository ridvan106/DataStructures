/**
 *
 * @author Rıdvan Demirci 141044070
 */
@SuppressWarnings("unchecked")
public class Soru2Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      try{
        soru2test t = new soru2test();
          t.test1();
         // t.test2();
          
      }
        
        
    
    
    catch(Exception e){
        System.out.println("Exception handle");
        e.getMessage();
}
    

}
}
