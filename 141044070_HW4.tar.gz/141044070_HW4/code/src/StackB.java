
import java.util.ArrayList;



/**
 * StackB Arraylisti composution olarak kullanır
 * @author Rıdvan Demirci 141044070
 */
@SuppressWarnings("unchecked")
public class StackB<E> implements StackInterface<E>{
    /**
     * Stack Size
     */
    private int size;
    /**
     * ArrayList Composition
     */
    private ArrayList data;

    /**
     * Default Constructure Size = 0
     */
    public StackB() {
        size = 0;
        data = new ArrayList();
    }

    /**
     * Stackin sonuna data ekler
     * @param data eklenecek data
     */
    @Override
    public void push(E data) {
        this.data.add(data);
        size++;
    }
    
    /**
     * Stackin Sonundaki elemanı cikarır
     * @return 
     */
    
    @Override
    public E pop() {
        if(size == 0){
            throw new IndexOutOfBoundsException("Pop olmaz Size 0 'dır Exception"
                    + " fırlatıldı");
        }
        else{
        E temp = (E)data.get(size - 1);
        data.remove(--size);
        return temp;
        } 
    }
   

    /**
     * Stack bosmu diye kontrol edilir size ile
     * @return  true or false
     */
    @Override
    public boolean isEmpty() {
        return (this.size() == 0);
    }

    /**
     * Stack Size
     * @return  Stack Size
     */
    @Override
    public int size() {
     return size;
    }

    
    
    
}
