
/**
 * Node lar kullanılırak Stack işlemi
 * @author Rıdvan Demirci 141044070
 */
@SuppressWarnings("unchecked")
public class StackC<E> implements StackInterface<E>{
    /**
     * Head Nodu 
     */
    private Node<E> head = null;
    /**
     * Eklemek kolay olsun diye Last node
     */
    private Node<E> Last;
    /**
     * Stack Size
     */
    private int size;
    /**
     * Default Constructure size =0
     */
    public StackC(){
        size = 0;
    }
    /**
     * Stackin sonuna eleman ekler
     * @param data eklenecek olan veri
     */
    @Override
    public void push(E data) {
        
        if(size == 0){ // ilk eleman eklenecekse
            Node<E> temp = new Node(data);
            head = temp;
            Last = head;
        }else if(size > 0){ // devamına eklenecekse
            Node temp1 = head;
            for (int i = 0; i < size -1 ; i++) {
                temp1 = temp1.next;
            }
            Last = temp1;
            Last.next = new Node(data,Last.next);
        }
        size++;
        
    }
    /**
     * Stackin sonundan Eleman cikarir
     * @return  Son elemanı return eder
     */

    @Override
    public E pop() {
        if(size == 0){
            throw new IndexOutOfBoundsException("Pop olmaz Size 0 'dır Exception"
                    + " fırlatıldı");
        }
        Node<E> temp = getNode(size-1);
        E tempData = temp.data;
        size--;
        temp = getNode(size-1);
        temp.next=null;
        return tempData;
    }

    /**
     * Bos olup olmadıgı kontrol edilir
     * @return  true or false
     */
    @Override
    public boolean isEmpty() {
        return (size == 0);
    }

    /**
     * 
     * @return Stack Size
     */
    @Override
    public int size() {
        return size;
    }
    /**
     * ihtiyaç olan indisdeki node return edilir
     * @param index istenilen indis
     * @return gereken node
     */
    
    private Node<E> getNode(int index){
        Node<E> node = head;
        for (int i = 0; i < index && node != null; i++) {
            node = node.next;
        }
        return node;
    }
/**
 * Static private class
 * @param <E> 
 */
private static class Node<E>{
    private E data;
    private Node<E> next;
    private Node(E data){
        this.data = data;
        this.next = null;
    }
    private Node(E data,Node<E> node){
        this.data = data;
        this.next = node;
    }
}
}
