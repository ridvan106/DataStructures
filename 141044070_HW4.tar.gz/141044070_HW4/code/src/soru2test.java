
import java.io.*;
import java.util.*;



/**
 *  test.csv den satırları okuyup ters çevirip result.csv ye yazar
 * @author Rıdvan Demirci 141044070
 */
@SuppressWarnings("unchecked")
public class soru2test {    
    /**
     * myQueue classını test etmek için yazıldı
     * satırları oku myQueue ye atar ve ters çevirir
     * satır ve sutunu
     */
    public void test1(){
        try{            
        File fp = new File("test.csv");
        Scanner fileScanner = new  Scanner(fp);
        File Writefp = new File("testResult_2.csv");
        FileWriter fwrite = new FileWriter(Writefp);
        BufferedWriter bfwriter = new BufferedWriter(fwrite);
        
        myQueue line = new myQueue(); // satırları okur
         while(fileScanner.hasNextLine()){
             myQueue columb = new  myQueue();
             String [] temp = fileScanner.nextLine().split(",");
             for (int i = 0; i < temp.length; i++) {
                 columb.offer(temp[i]);     // satırları parçalayarak okur   
             }
             columb.reverse(); // okudugu satırın verilerini ters çevirir
             String tempp="";
             while(columb.size()>0){
                 tempp+=columb.poll().toString()+","; // ters çevrilen veri stringe atılır
             }
             line.offer(tempp); //ters çevrilmiş satır ayırı bir myQueue ye atılır
         }
         line.reverse();    // ensonda tüm satırlar ters çevirilir
         while(line.size()>0){
             String temp =line.poll().toString();
             temp = temp.substring(0, temp.length()-1); // sondaki ekstra virgülü siler
             bfwriter.append(temp+"\n");
         }  // dosyaya yazılır
              
              
         
             
         
         bfwriter.close();
      fwrite.close();
        
        
    }
        catch (Exception e){
            
            
        }
}
    /**
     * test1 ile aynı şekilde satır ve sutunları ters çevirip
     * result.csv ye atar
     */
    public void test2(){
        Queue siralama = new ArrayDeque(); // Queue tanımlamak için arrayDequeu
        myQueue temp = new myQueue();// sadece normal queue tersi için tanımlandı
        try{            
        File fp = new File("test.csv");
        Scanner fileScanner = new  Scanner(fp);
        File Writefp = new File("result.csv");
        FileWriter fwrite = new FileWriter(Writefp);
        BufferedWriter bfwriter = new BufferedWriter(fwrite);
        
           while(fileScanner.hasNextLine()){
             Queue columb = new ArrayDeque(); // sutunlar için Queue
             String [] line = fileScanner.nextLine().split(",");
             for (int i = 0; i < line.length; i++) {
                 columb.offer(line[i]);       //veri virgüle göre parçalanır ve queue ye atılır              
             }
              temp.reverseQueue(columb);  // queue columbları ters çevirilir
             String tempp="";
             while(columb.size()>0){
                 tempp+=columb.poll().toString()+","; // rest çevirilen satır Stringe atılır
             }
             siralama.offer(tempp); // string de Queue ye atılır
           }
            temp.reverseQueue(siralama); // Queue toplam satırları yer değiştirilir
            
            // result.csv ye yazılır
         while(siralama.size()>0){
             String write =siralama.poll().toString();
             write = write.substring(0, write.length()-1); // sondaki ekstra virgülü siler
             bfwriter.append(write+"\n");
         }
         bfwriter.close();
         fwrite.close();
        
        }catch(Exception e){
            
            
        }
        
    }
}