
import javax.lang.model.element.Name;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Rıdvan Demirci 141044070
 */
public class FamilyTree<E> extends BinaryTree<E>{

    /**
     * Root oluşturan constructure
     * @param name 
     */
    public FamilyTree(String name) {
        super.root = new Node<E>((E)name);
    }
    /**
     * Agaca veri eklemek için kullanılan public method
     * @param name kişinin adı
     * @param ParentName parent name
     * @param NickName  ibn or ebu
     * @return true or false
     */
    public boolean add(String name,String ParentName,String NickName){
        return add(root,name,ParentName,NickName);
        
    }
    /**
     * Agaça asıl ekleme işlemi burada yapılır kontroller de burada yapılır
     * @param root ata parent
     * @param name eklenecek olan isim
     * @param ParentName parent name
     * @param NickName ebu or ibn
     * @return 
     */
    public boolean add(Node root,String name,String ParentName,String NickName){
        if(root == null)
            throw new NullPointerException("root yok");
        else{
            if(ParentName.equals(root.data)){ // eger rootun altında ise
                String temp = NickName.substring(4);//ön adı atmak için
                String nick = NickName.substring(0,3);
                // Ana roota ekleme olayı
                if(temp.equals(name)){ // eger sıfat direk isme eşitise parentın cocugudur
                    // saga veya sola ekler direk rootun cacugudur
                    if(root.left == null){
                        
                        root.left = new Node<>(name);
                    }
                    else if(root.left != null){
                        root.left = addRight(root.left,(E)name);
                    }

                    else{
                        System.out.println("unreasinable state");
                        System.exit(1);
                    }
                    // eger iki cocuklarıda dolu ise yanlıstır
                }
                // eger sıfat isimden farklı ise soluna veya salına eklenecek
                // solda ise soluna 
                // degil ise sagina eklenir
                else if(find(root.left, temp) == null){
                    if(nick.equals("ebu")){

                        root.left.right = new Node(name);
                    }
                    else if(nick.equals("ibn")){
                        root.left = new Node(name);
                    }
                    else {
                        System.out.println("unrasional case");
                        System.exit(1);
                    }
                }
                else if(find(root.left,temp) != null){
                    if(nick.equals("ebu")){
                        root= addRight(find(root,temp),(E)name);

                    }
                    else {

                        find(root.left,temp).left = new Node(name);
                    }
                }
                else if(find(root.right,temp) == null)
                {
                    if(nick.equals("ebu")){
                    root = new Node(name);
                }
                    else if(nick.equals("ibn")){
                        root.left = new Node(name);
                    }
                    else{
                        System.out.println("unrasional case");
                        System.exit(1);
                    }
                }
                else if(find(root.right,temp) != null){
                    if(nick.equals("ebu")){
                        root= addRight(find(root,temp),(E)name);

                    }
                    else {

                        root= addRight(find(root.left,temp),(E)name);
                    }
                }
                else{ // egertemp ana kök ise
                    System.out.println("unrasional case");
                    System.exit(1);
                }
            
            }// parentName root değil ise yani çocuk ise 
            // yerini bulur ve sonrasına ekler
            else {
                if(find(root.left,ParentName) != null){ // sol tarafta ise sol agaci gonderir
                   return add(root.left,name,ParentName,NickName);
                }
                else if(find(root.right,ParentName) != null){
                    //sag tarafta ise sag agaci gonderir
                    return add(root.right,name,ParentName,NickName);
                }
                else{
                    // eger oyle bir agac yoksa
                    System.out.println("hatalı parent");
                    System.exit(0);
                }
            }
                
            
            
        
        return true;
    }}
    /**
     * verilen agacta itemi arar
     * @param root agac
     * @param item deger
     * @return 
     */
    public Node find(Node root,String item){
        if(root == null){
            return null;
        }
        if(root.data.equals(item))
            return root;
        
        else{
            Node temp = find(root.left, item);
            if(temp == null)
            return  find(root.right,item);


            return temp;

        }
        
    }
    /**
     * agaca veri ekleme yapısı
     * @param root agac yapısı
     * @param Item eklenecek deger
     * @return node
     */
    private Node add(Node root,String Item){
        root = getNodeWhere(root, (E)Item);
        return root;
        
    }

    private Node addRight(Node root,E data){
        if(root == null){
            System.out.println("unrasionable case");
            System.exit(1);
            return null;
        }
        else if (root.right == null){
            root.right = new Node(data);
            return root;

        }
        else{
            return addRight(root.right,data);
        }

    }
    
    @Override
    public void traverse(){
        getPreorder(root);
        
    }
    
    /**
     * public trevarse için ekrana yazdırır
     * @param root 
     */
    private void getPreorder(Node root){
        if(root == null){
            
        }else{
            System.out.print(root.data.toString() + "  ");
            getPreorder(root.left);
            getPreorder(root.right);
        }
    }
    
    /**
     * Iterator için get preOrder overload edildi
     * @param root agac root u
     * @param sb  degerleri ıterator için arrayListe alır
     */
    private void getPreorder(Node root,ArrayList<String> sb){
        if(root == null){
            
        }else{
            sb.add(root.data.toString());
            getPreorder(root.left,sb);
            getPreorder(root.right,sb);
        }
    }
    /**
     * Gelen veriyi node da ilgili yere ekler
     * @param root agac yapısı
     * @param data eklenecek veri
     * @return  yeni rootu return eder
     */
    @Override
    protected Node <E> getNodeWhere(Node<E> root,E data){
        // root yok ise direk oraya ekliycek
        if(root == null){
            return new Node<E>(data);
        }
        // sol boş ise sola ekleycek
        else if(root.left == null){
            root.left = new Node<E>(data);
            return root;
        }
        // sag cocuk boş ise sol cocugu kontrol edip saga eleme yapıcak
        else if(root.right == null){
            if(root.left.data.equals(data)){
                throw new IllegalStateException("Kişi Eklenemedi aynı kişi");
            }
            root.right = new Node<E>(data);
            return root;
        }
        // eger agacın hepsi dolu ise perfect tree mantıgı ile uygun yere koycak
        else{  
            /*
            eger rootun sagi ve soluda doluysa alt nodeları doldurmaya baslar
            yükseklik hep sola eklendigi için sag taraftan itibaren yapılarak gider
            */
            int Hleft = helperHeigh(root.left);
            int Hright = helperHeigh(root.right);
            if(Hleft == Hright){
                root.left=getNodeWhere(root.left, data);
            }
            else{//sag agac kucukse dolması lazım
                
             root.right = getNodeWhere(root.right, data);
            }           
            return root;
        }
        
    }
    
    /**
     * verilere pre-pre order gezen Iterator
     * @return 
     */
    @Override
    public Iterator<E> iterator() {
        ArrayList<String> sb = new ArrayList<>();
        getPreorder(root, sb);
        int mysize = sb.size();
        
        Iterator iter = new Iterator() {
            int count = 0;
            @Override
            public boolean hasNext() {
                return count < mysize;
            }

            @Override
            public Object next() {
                String temp = sb.get(count);
                count++;
                return temp;
            }
            @Override
            public void remove(){
                throw new UnsupportedOperationException("Silme basarisiz");
            }
        };
                return iter;
    
    }
    
}
