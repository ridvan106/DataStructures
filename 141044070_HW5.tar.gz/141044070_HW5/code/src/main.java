
import java.io.File;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author Rıdvan Demirci 141044070
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            
            

       File fp = new File("test.txt");
        Scanner sc = new Scanner(fp);
        BinarySearchTree<Integer> BStree = new BinarySearchTree<Integer>();
        BinaryTree<Integer> Btree = new BinaryTree<Integer>();
        Btree.readBinaryThree(sc);
        sc = new Scanner(fp);
        while(sc.hasNext()){
            BStree.add(sc.nextInt());
        }
            System.out.println("1.Soru Cıktısı\nBinary Tree Traverse preOrder");
        Btree.traverse();
        System.out.println("\n Binary Search Tree Traverse Level Order");
        BStree.traverse();
        System.out.println();

             /**
              * Family tree için Dosyadan okuyup ekleme
              * ve Iteratorle traverse etme
              */
             File familyFile = new File("family.txt");
           Scanner familyScanner = new Scanner(familyFile);
           String root = familyScanner.nextLine().trim();
           
           FamilyTree family = new FamilyTree(root);
           
           while(familyScanner.hasNext()){
               String [] temp = familyScanner.nextLine().split(","); 
               String name = temp[0].trim();
               String Parent = temp[1].trim();
               String nickName = temp[2].trim();
               family.add(name, Parent,nickName);
           }
            
           System.out.println("2.Soru Cıktısı");
            Iterator<String> itr = family.iterator();
            while(itr.hasNext())
            System.out.print(itr.next() + "  ");
            
          
        
    }catch(Exception e){
        
        System.out.println(e.getMessage());
    }
    
}
}
