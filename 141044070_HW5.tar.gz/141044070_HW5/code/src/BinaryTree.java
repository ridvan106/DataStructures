import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 * dosyadan okunan verileri perfect three ye yerleştirir
 * @author Rıdvan Demirci 141044070
 * @param <E> generik tip
 */
public class BinaryTree<E> implements Iterable<E>,Serializable{
    /**
     * BinaryTree rootunu tutar
     */
    protected Node<E> root;
    /**
     * default constructure hiçbirşey yapmaz
     */
    public BinaryTree(){
        root = null;
    }
    /**
     * root alan constructure
     * @param root root alır
     */
    public BinaryTree(Node<E> root){
        this.root = root;
    }
    /**
     * butun olarak agac yapısı alırsa
     * @param data node verisi
     * @param lefttree sol agac
     * @param rightthree  sag agac
     */
    public BinaryTree(E data,BinaryTree<E> lefttree,BinaryTree<E> rightthree){
        root = new Node<E>(data);
        if (lefttree != null) {
        root.left = lefttree.root;
        }
        else{
            root.left = null;
        }
        if(rightthree != null)
        root.right = rightthree.root;
        else
            root.right = null;
        
    }
    /**
     * Sol agac
     * @return sol three
     */
    public BinaryTree<E> getLeftSubtree(){
        if(root.left != null){
            return new BinaryTree<E>(root.left);
        }
        return null;
    }
       /**
     * sag agac
     * @return sol three
     */
    public BinaryTree<E> getRightSubtree(){
        if(root.right != null){
            return new BinaryTree<E>(root.right);
        }
        return null;
    }
    /**
     * data
     * @return rootun verisi return edilir
     */
    public E getData(){
        if(root != null){
            return root.data;
        }
        return null;
    }
    /**
     * leaf olup olmadıgı kontrol edilir
     * @return true or false
     */
    public boolean isLeaf(){
        return (root.left == null && root.right == null);
    }
   
     /** Perform a preorder traversal.
      @param node The local root
      @param depth The depth
      @param sb The string buffer to save the output
   */
    private void preOrderTraverse(Node < E > node,ArrayList<E> sb) {
     
      if (node == null) {
          
      }
      else {
          sb.add(node.data); 
          preOrderTraverse(node.left,sb);
           
          preOrderTraverse(node.right, sb);
               
       
        
        
      }
    }
    
    /**
     * Dosyadan verileri okur
     * @param scan dosyadan okuma parametresi
     */    
    public  void readBinaryThree(Scanner scan){
            while(scan.hasNext()){
               root= getNodeWhere(root,(E)scan.next());
               
            }
            
    }
    
     /**
     * Perfect tree ye goren nereye eklenmesi gerekrtiğine karar
     * verir
     * @param root eklenecek agac
     * @param data eklenecek veri
     * @return  eklenmis olarak agac return eder
     */
    protected Node <E> getNodeWhere(Node<E> root,E data){
        if(root == null){
            return new Node<E>(data);
        }
        else if(root.left == null){
            root.left = new Node<E>(data);
            return root;
        }
        else if(root.right == null){
            root.right = new Node<E>(data);
            return root;
        }
        else{  
            /*
            eger rootun sagi ve soluda doluysa alt nodeları doldurmaya baslar
            
            */
            int Hleft = helperHeigh(root.left);
            int Hright = helperHeigh(root.right);
            if(Hleft == Hright){
                root.left=getNodeWhere(root.left, data);
            }
            else{//sag agac kucukse dolması lazım
                
             root.right = getNodeWhere(root.right, data);
            }           
            return root;
        }
        
    }
    /**
     * verilen agacın sag taraf baz alınarak yukseklik olcer
     * @param root agac
     * @return  yukseklik
     */
    protected int helperHeigh(Node <E> root){
        if(root == null)
            return 0;
        int heigh = 0;
        while(root.right != null){
            heigh++;
            root = root.right;
            
        }
        return heigh;
        
        
    }
    
    /**
     * test için istenilen traverse methodu
     */
    public void traverse(){
        if(root == null){
            System.out.println("treversa yapılamaz veri eklenmeli");
             System.exit(0);
        }
        Iterator<E> itr = this.iterator();
          while(itr.hasNext()){
           System.out.print(itr.next() +"  ");
       }
        
    }
    
    /**
     * Iterator methodu degerleri preorder olarak dolsır 
     * degerleri arrayListe atar
     * @return 
     */
    
    @Override
    public Iterator<E> iterator() {
        ArrayList<E> sb = new ArrayList<E>();
        preOrderTraverse(root, sb);
        Iterator<E> Itr = new Iterator<E>() {
            int mysize = sb.size();
            int count=0;
            @Override
            public boolean hasNext() {
                return count<mysize;
            }

            @Override
            public E next() {
                 E temp = (E)sb.get(count);
                 count++;
                 return temp;
            }
            
            @Override
            public void remove(){
                throw new UnsupportedOperationException();
            }
            
        };
        return Itr;
    } 
    
    
    
    /**
     * Static NOde
     * @param <E> Generik tipinde
     */
    protected static class Node<E> implements Serializable{
        /**
         * Nodun datası 
         */
        protected E data;
        /**
         * sol cocuklar
         */
        protected Node<E> left;
        /**
         * sag cocuklar
         */
        protected Node<E> right;
        /**
         * constructure
         * @param data node datası
         */
        public Node(E data){
            this.data = data;
            this.left = null;
            this.right = null;            
        }
    }
        
  
    
}
