
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Rıdvan Demirci 141044070
 * @param <E>
 */
public class BinarySearchTree<E extends Comparable<E>> extends BinaryTree<E> implements SearchTree<E>{
    protected boolean addReturn;
    protected E deleteReturn;
    

    @Override
    public boolean add(E item) {
        super.root = add(super.root,item);
        return addReturn;
    }
    private Node<E> add(Node<E> localRoot,E item){
        if(localRoot == null){//ilk ekleme node null ise
            addReturn = true;
            return new Node<E>(item);            
        }
        else if(item.compareTo(localRoot.data) == 0){
            // eger O veride varsa tekrar eklemez
            addReturn = false;
            return localRoot;
            
        }
        else if(item.compareTo(localRoot.data) < 0){
            //item root dan küçük ise
            localRoot.left = add(localRoot.left, item);
            return localRoot;
        }
        else{
            //item root dan Büyük ise
            localRoot.right = add(localRoot.right, item);
            return localRoot;
        }
    }
    
   /**
    * tree yi levelOrder olarak gezer ve arrayListe atar
    * fonksyon verilen itemın roota olan uzaklıklarını baz alarak
    * çalışır
    * verilen level ile o levelde olan itemları
    * arrayliste ekler
    * @param root root
    * @param level gelen seviye
    * @param sb arrayList
    */
    private void getLevelOreder(Node<E> root,int level,ArrayList<E> sb){
        if(root == null){
            
        }
        // verilen seviyedeki item
        else if(getHeight() - where(super.root, root.data) == level){
            sb.add(root.data);
        }
        else{
            //yok ise sag ve sol çocuklar
            getLevelOreder(root.right, level,sb);
            getLevelOreder(root.left, level,sb);
            
        }
        
    }
    private int getHeight(){
        return treeLevel(super.root);
    }
    /**
     * 
     * @param node verilen nodeun yuksekligini ölçer
     * maximum yuksekliği
     * @return 
     */
    private int treeLevel(Node<E> node){
        if(node == null)
            return 0;
        else{
            int heighLeft =1 + treeLevel(node.left);
            int heighRight = 1 + treeLevel(node.right);
            //maximum yukseklik alınmalı
            if(heighLeft > heighRight)
                return heighLeft;
            return heighRight;
        }
    }
    
    /**
     * Bu method verilen Item ın roota olan yuksekliğini return eder
     * @param root root
     * @param data data
     * @return roota olan yukseklik
     */
    
    private int where(Node<E> root ,E data){
        if(root == null){
            return 0;
        }
        else if(root.data == data) {
            return 1;
            
        }
        else{
            // eger node dan kucuk ise sol agac
            if(data.compareTo(root.data) < 0)            
            return 1 + where(root.left,data);
            else
            return 1 + where(root.right, data);
        }
    }
    
    /**
     * binary search deki iterator overload edildi
     * level order olarak agacı gezer
     * @return 
     */
    @Override
    public Iterator<E> iterator(){
        ArrayList<E> sb = new ArrayList<E>();
         for (int i = 0; i < getHeight(); i++) {
            getLevelOreder(root, i,sb); // arrayliste verileri pre order olarak 
        }
          Iterator<E> Itr = new Iterator<E>() {
            int mysize = sb.size();
            @Override
            public boolean hasNext() {
                return mysize>0;
            }

            @Override
            public E next() {
                if(mysize == 0){
                    System.out.println("next yapılamaz veri eklenmeli");
                    System.exit(1);
                }
                 E temp = (E)sb.get(mysize-1);
                 mysize--;
                 return temp;
            }
            
            @Override
            public void remove(){
                throw new UnsupportedOperationException();
            }
            
        };
        return Itr;
        
    }

    @Override
    public boolean contains(E target) {
    return find(target) != null;
  }

    /**
     * find methodu testlerde olmadıgı için direk 
     * kitapdan aldım
     * @param target aranan
     * @return bulur 
     */
    @Override
    public E find(E target) {
    return find(root, target);
  }

  /** Recursive find method.
      @param localRoot The local subtrees root
      @param target The object being sought
      @return The object, if found, otherwise null
   */
  private E find(Node < E > localRoot, E target) {
    if (localRoot == null)
      return null;

    // Compare the target with the data field at the root.
    int compResult = target.compareTo(localRoot.data);
    if (compResult == 0)
      return localRoot.data;
    else if (compResult < 0)
      return find(localRoot.left, target);
    else
      return find(localRoot.right, target);
  }

  /**
   * delete methodu çıkarılacak nodun solundaki en büyük nodu 
   * koyar yerine findLargest helper method
   * kitapdan alındı
   * @param target
   * @return 
   */
    @Override
    public E delete(E target) {
        root = delete(root,target);
        return deleteReturn;
    }
    private Node<E> delete(Node<E> localRoot,E item){
        if(localRoot == null){ // silinecek item yok
            deleteReturn = null;
            return localRoot;
        }
        int compResult = item.compareTo(localRoot.data);
        if(compResult < 0){
            localRoot.left = delete(localRoot.left, item);
            return localRoot;
        }
        else if(compResult > 0){
            localRoot.right = delete(localRoot.right,item);
            return localRoot;
        }else{
            // aranan item bulundu
            deleteReturn = localRoot.data;
            if(localRoot.left == null){ //sol cocuk yoksa 
                return localRoot.right;
            }
            else if (localRoot.right == null) {
                  // If there is no right child, return left child.
             return localRoot.left;
            }
            else{
                 if (localRoot.left.right == null) {
                     localRoot.data = localRoot.left.data;
                     localRoot.left = localRoot.left.left;
                     return localRoot;
                 }
                 else{
                     localRoot.data = findLargestChild(localRoot.left);
                     return localRoot;
                 }
            }
        }
    }
    /**
     * verilen nodun en buyuk degerini bulur
     * @param parent
     * @return 
     */
    private E findLargestChild(Node < E > parent) {
       // If the right child has no right child, it is
       // the inorder predecessor.
       if (parent.right.right == null) {
         E returnValue = parent.right.data;
         parent.right = parent.right.left;
         return returnValue;
       }
       else {
         return findLargestChild(parent.right);
       }
     }
    @Override
    public boolean remove(E target) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void traverse(){
        if(root == null){
            System.out.println("treversa yapılamaz veri eklenmeli");
             System.exit(0);
        }
        Iterator<E> itr = this.iterator();
          while(itr.hasNext()){
           System.out.print(itr.next() +"  ");
       }
        
    }
    
    
}
