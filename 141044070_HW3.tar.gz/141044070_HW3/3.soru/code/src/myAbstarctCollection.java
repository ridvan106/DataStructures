
import java.util.AbstractCollection;
import java.util.Iterator;

/**
 * abstractCollectiondan türeyen class appendAnything methodu ile
 * 2 tane myAbstractCollection ı birbirine ekler
 * @author Rıdvan Demirci 141044070
 * @param <E>
 */
public abstract class myAbstarctCollection<E> extends AbstractCollection {
    
    /**
     * myAbstruct alır ve iteretorun add methoduyla 
     * kendine ekler extend  edilen classlarda ise iteretor
     * add ve size() methodu override edilmeli
     * @param other Gelen deger 
     */
   
    public void appendAnything(myAbstarctCollection other){
        
        Iterator itarator = other.iterator();
        for (int i = 0; i < other.size(); i++) {
           if(itarator.hasNext()){
               this.add(itarator.next());
           }
        }
        
        
        
    }
  
}
