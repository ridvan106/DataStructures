
import java.util.Iterator;


/**
 * class ödevde olmadıgı halde appendAnything çalışıp
 * çalışmaması nı kontrol için hazırlandı
 * @author Rıdvan Demirci 141044070
 * @param <E>
 */
public class test<E> extends myAbstarctCollection<E>{

    /**
     * sınıfın datası object array
     */
    protected Object [] data;   
    /**
     * arrayde olan veri sayısı
     */
    protected int size = 0;
    /**
     * array için ayrılan capasity
     */
    private int capasity =50;
    /*
    default constructure
    */
    public test(){
        data =(E[]) new Object[capasity];
    }
   
/**
 * abstract collectindan gelen add methodu
 * dataya sıralı şekilde ekler
 * @param e Item
 * @return true or false
 */
    @Override
    public boolean add(Object e) {
        if(capasity - size == 2){
            setStringCapasity();
        }
        data[size] = e;
        size++;
        return true;
       }
   
    /**
     * reallocation
     */
    private void setStringCapasity(){
        Object [] temp = (E[]) new Object[capasity];
        for (int i = 0; i < size; i++) {
            temp[i] = data[i];
        }
        capasity = capasity*2;
        data =(E[]) new Object[capasity];
        for (int i = 0; i < size; i++) {
            data[i] = temp[i];
        }
        temp = null;
        
    }
    /**
     * Iterable dan gelen Iteratıor methodu
     * @return  İterartor
     */
         @Override
    public Iterator iterator() {
        Iterator itr = new Iterator() {
            private int IteratorIndis=0;
            @Override
            public boolean hasNext() {
               if(IteratorIndis < size()){
                   return true;
               }
               return false;
            }

            @Override
            public E next() {
               
               return (E)data[IteratorIndis++];
            }
            
        };
                return itr;
         }  
    

    /**
     * abstract collectiondan gelen size
     * @return size
     */
    @Override
    public int size() {
       return  this.size;
    }
      @Override
    public String toString(){
        String temp="";
        Iterator itr = this.iterator();
        while(itr.hasNext()){
            temp += itr.next().toString()+"\n";
        }
        return temp;
    }
}
    
  
                

    

