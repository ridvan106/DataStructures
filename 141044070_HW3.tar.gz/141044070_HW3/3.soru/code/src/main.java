/**
 * deneme için main 2 tane faklı tipteki 
 * myAbstractCollectiondan türeyen sınıfa
 * append methodu uygulanması
 * @author Rıdvan Demirci 141044070
 */
public class main {

    /**
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        test<Integer> a = new test<>();
        test<String> b = new test<>();
       
        a.add(4);
        a.add(6);
        a.add(1);
        b.add(5);
        b.add(9);
        b.add(900);
         a.add(1);
        b.add(5);
        b.add(9);
        b.add(900);
        a.appendAnything(b);
        System.out.println(a);
    }
    
}
