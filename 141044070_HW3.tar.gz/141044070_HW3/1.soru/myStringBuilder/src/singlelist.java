
/**
 *Single Linked listin implement etmesi gereken
 * interface
 * @author Rıdvan Demirci 141044070
 * @param <E>
 */
public interface singlelist<E> {
    /**
     * 
     * @param i gereken indis
     * @return verisi
     */
   public E get(int i);
   /**
    * 
    * @param i indis 
    * @param veri  veri
    */
   public void set(int i, E veri);

    /**
     *
     * @return size
     */
    public int size();
    /**
     * 
     * @param i indis return eder
     * @param veri gereken veri
     */
   public void add(int i,E veri);
   
}
