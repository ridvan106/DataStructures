
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;



/**
 * 100.000 tane sayıyı numbers.txt ye ekler
 * @author Rıdvan Demirci 141044070
 */
public class testwriteNumbers {
    /**
     * 10.000 tane sayıy numbers.txt de ye doldurur
     */
    public void write100Numbers(){
        FileWriter write = null;
        try {
            File file = new File("numbers.txt");
            write = new FileWriter(file);
            BufferedWriter bfw = new BufferedWriter(write); // dosya olusturma
            Random rd = new Random();// raskele sayı olusturma
            for (int i = 0; i < 10000; i++) {
                int num = rd.nextInt(500); // 0-500 arası
                bfw.write(num+"\n"); // altalta yazar
            }
            bfw.close();
            write.close();
        }
        catch (IOException ex) {
            System.out.print("Exception Related to File\n");
        } 
        
        
    }
    
}
