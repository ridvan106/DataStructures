
import java.util.Iterator;

/**
 * builder class
 * @author Rıdvan Demirci 141044070
 */
public class myStringBuilder extends strBuilder{
     private mySingleLinked<Object> list = new mySingleLinked<Object>();
     private int count=0;
   
/**
 * 
 * @param num  integer verilirse
 */
    @Override
    public void append(int num) {
        Integer temp = Integer.valueOf(num);
       list.add(num);
    }
    /**
     * 
     * @param str String verilirse
     */
    @Override
    public void append(String str) {
        list.add(str); 
    }
    
    /**
     * Object verilirse
     * @param obj 
     */
    @Override
    public void append(Object obj) {
        list.add(obj);
    }
    
    /**
     * 
     * @param bool Boolean verilirse
     */
    @Override
    public void append(boolean bool) {
       list.add(bool);
    }
    
    /**
     * 
     * @param c char verilirse
     */
    @Override
    public void append(char c) {
       list.add(c);
    }
    
    /**
     * 
     * @param cstr char pointer verilirse
     */
    @Override
    public void append(char[] cstr) {
        String temp = String.valueOf(cstr);
        list.add(cstr);
    }
    
    /**
     * 
     * @param dbls  Double verilirse
     */
    @Override
    public void append(double dbls) {
        Double temp = Double.valueOf(dbls);
        list.add(dbls);
    }
    /**
     * get index ile istenen toString
     * ve 
     * @return string birleşmeyi return eder
     */
     @Override
    public String toString(){
        String temp ="";
        for (int i = 0; i < list.size(); i++) {
            temp+=list.get(i).toString()+"\n";
            
        }
        return temp;
        
    }
    /**
     * kendi yazdıgım iteratoru kullanarak 
     * toString olusturdum
     * @return Olusturulan String return edilir
     */
    public String toStringIterator(){
        Iterator<Object> itr = list.iterator();
        String temp ="";
        while(itr.hasNext()){
            temp+= itr.next().toString()+"\n";
            
        }
        return temp;
    }
    /**
     * SingleLinkedList in toString methodu 
     * return edilir
     * @return 
     */
    public String toStringLinkedList() {
        return list.toString();
    }
    

           
}
