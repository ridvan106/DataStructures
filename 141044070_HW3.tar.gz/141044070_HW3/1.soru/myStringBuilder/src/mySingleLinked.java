
import java.util.Iterator;




/**
 * single Linklist Inner class olarak node kullanılmıstır
 * ve Kitapdan fatdalanılmıstır ...
 * @author Rıdvan Demirci 141044070
 * @param <E> generik
 */

public class mySingleLinked<E> implements singlelist<E>{
    private Node<E> head = null;
    private int size;
    /**
     * ilk node ekleme
     * @param item  itemı ilk node a ekleme
     */
    public void addFirst(E item){
        
        head = new Node<E>(item,head);
        size++;
        
    }
    /**
     * Hangi nodden sonra ekleyecegini hesaplar
     * @param nextNode //hangi noddan sonra
     * @param item  //yeni node un itemı
     */
    private void addAfter(Node<E> nextNode,E item){
        nextNode.next = new Node<E>(item,nextNode.next);
        size++;
    }
    /**
     * hangi node dan sonrasını sileceği belirlenir
     * ve o nodu return eder
     * @param node   sonrasının silenecegi node
     * @return       nodun datası return edilir
     */
    private E removeAfter(Node<E> node){
        Node<E> temp = node.next;
        if(temp != null){
            node.next = temp.next;
            size--;
            return temp.data;
        }
        else{
            return null;
        }
    }
    /**
     * ilk nodu siler head bos degilse head i bir 
     * sonrakinin nexti yapar ve temp null dan farklı ise 
     * onu return eder
     * @return 
     */
    private E removeFirst(){
        Node<E> temp = head;
        if(head != null){
            head = head.next;
        }
        if(temp != null){
            size--;
            return temp.data;
        }else{
            return null;
        }
    }
    /**
     * public yapılacak get methodu için helper method
     * @param index hangi node return edilcek
     * @return secilen node return edilir
     */
    private Node<E> getNode(int index){
        Node<E> node = head;
        for (int i = 0; i < index && node != null; i++) {
            node = node.next;
        }
        return node;
    }
    /**
     * secilen nodun  datasını return eder ve
     * helper method kullanır
     * @param i secilen index
     * @return return datası
     */
    @Override
    public E get(int i){
        if(i<0 || i>size){
            System.out.print("index out of bounds");
            throw new IndexOutOfBoundsException();
        }
        return getNode(i).data;
    }
    /**
     * Secilen index'in datasına verilen degeri atar
     * @param i verilen index
     * @param val  verilen deger
     */
    @Override
    public void set(int i,E val){
        if(i<0 || i>=size){
            System.out.print("index out of bounds");
            throw new IndexOutOfBoundsException();
        }
        Node<E> node = getNode(i);
        node.data = val;
    }
    /**
     * verilen index a veriyi ekler
     * @param i index degeri
     * @param veri  data
     */
    /**
     * verilen yere veri ile beraber node ekler
     * @param i indis
     * @param veri data
     */
    @Override
    public void add(int i,E veri){
         if(i<0 || i>size){
            System.out.print("index out of bounds");
            throw new IndexOutOfBoundsException();
        }
         if(i == 0){
             addFirst(veri);
         }
         else{
             Node<E> temp = getNode(i-1);
             addAfter(temp, veri);
         }
    }

    /**
     * 
     * @param item item
     * @return  return degeri
     */
    public boolean add(E item){
        add(size,item);
        return true;
    }
    
    /**
     *
     * @return
     */
   
    @Override
    public int size(){
        return size;
    }
    
    /**
     * link list üzerinde dolasmak için gereken Iterator
     * 
     * @return olusan iteratoru return eder
     */
    public Iterator<E> iterator(){
        Iterator<E> itr = new Iterator<E>() {
            int index = 0;
            /**
             * 
             * @return sonraki varsa true
             */
            @Override
            public boolean hasNext() {
                if(index < size){
                    return true;
                }
                return false;
            }

            /**
             * 
             * @return sonraki veriyi return eder
             */
            @Override
            public E next() {
                
               
                E temp = get(index);
                 index++;
                return temp;
                 }
            @Override
            public void remove( ){
                // nothing gerek yok
            }
        };
                return itr;
    }
    /**
     * Iterator kullanarak verileri String() olarak ekler
     * @return String
     */
    @Override
    public String toString(){
        String temp = "";
        Iterator<E> itarator = this.iterator();
        while(itarator.hasNext()){
            temp += itarator.next().toString()+"\n";
        }
        return temp;
    }
    /**
     * innew class nodu
     * @param <E>  generic tipinde
     */
    private  static class Node<E> {
    private E data;
    private Node<E> next;
    /**
     * constructure
     * @param data  default constructure
     */
    private Node(E data){
        
        this.data = data;
        next = null;
    }
    /**
     * yeni node olusturma
     * @param data verisi
     * @param node nodeun referansı 
     */
    private Node(E data,Node<E> node){
        this.data = data;
        next = node;
    }
          
    
}
    
   
}
