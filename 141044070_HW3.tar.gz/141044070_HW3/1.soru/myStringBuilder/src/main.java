import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;


/**
 * test etmek amacıyla bazı fpnksyonlar kullanılır
 * @author Rıdvan Demirci 141044070
 */
public class main {

    /**
     * mainde once dosyaya 100.000 sayı ekler sonra hepsi ayrı ayrı
     * ne kadar sure aldıgını hesaplar ve terminale basar
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        testwriteNumbers a = new testwriteNumbers();
        a.write100Numbers(); // dosyaya 100000 sayı yazar
        myStringBuilder str = new myStringBuilder();    
        File oku = new File("numbers.txt");
        try {
            /**
             * denenmek istenilen fonksyon çağrılır veya tüm hepsi 
             * çağrılır
             */
            
            System.out.println("1-)Uses indexes and get method");
            System.out.println("2-)Uses iterator");
            System.out.println("3-)Uses toString method of the linked list");
            System.out.println("4-)All of them");
            System.out.print("Please Select toString\n");
            Scanner selection = new Scanner(System.in);
            int secim = selection.nextInt();
            // ilgili secim yapılır
            Scanner sc = new Scanner(oku);
            while(sc.hasNext()){
                // Append komutu ile sayılar okunur
                str.append(sc.nextInt());
                
            } 
           File file = new File("result1.txt");
           FileWriter write = new FileWriter(file);
           BufferedWriter bfw = new BufferedWriter(write);
            // ilk toString yani get methodlu olan 
            long time = System.currentTimeMillis();// analiz icin timer
            if(secim == 1 || secim==4){
             bfw.write(str.toString());
            time = System.currentTimeMillis()- time;
            System.out.println("Uses indexes and get method per time:"+time+" ms");            
            bfw.close();
            write.close();
            }
         
            if(secim == 2 || secim==4){
            file = new File("result2.txt");
            write = new FileWriter(file);
            bfw = new  BufferedWriter(write);
            // ikinci toString Iteratorlu
            time = 0;
            time = System.currentTimeMillis(); // analiz icin timer
            bfw.write(str.toStringIterator());
            time = System.currentTimeMillis()- time; 
            System.out.println("Uses iterator time:"+time+" ms");
            bfw.close();
            write.close();
            }
          if(secim == 3 || secim==4){
            file = new File("result3.txt");
            write = new FileWriter(file);
            bfw = new  BufferedWriter(write);
            //3. tostring Linkedlist to string methodu
            
            time = System.currentTimeMillis(); // analiz icin timer
            bfw.write(str.toStringLinkedList());
            
            time = System.currentTimeMillis()- time;
            System.out.println("Uses toString method of the linked list per time:"+time+" ms");
            bfw.close();
            write.close();// Dosyalar kapatılır
        
          }
        }
        catch (Exception e) {
           
        }
        
        
              
        
               
          
    }
    
}
