
/**
 *String Builderin implement etmesi gereken interface
 * @author Rıdvan Demirci 141044070 
 */
public abstract class strBuilder {
    
    /**
     * 
     * @param num  sayi eklenirse
     */
    public abstract void append(int num);
    /**
     * 
     * @param str String eklenirse
     */
    public abstract void append(String str);
    /**
     * 
     * @param obj Object eklenirse
     */
    public abstract void append(Object obj);
    /**
     * 
     * @param bool Nool eklenirse
     */
    public abstract void append(boolean bool);
    /**
     * 
     * @param c Char Eklenirse
     */
    public abstract void append(char c);
    /**
     * 
     * @param cstr char pointer varsa
     */
    public abstract void append(char[] cstr);
    /**
     * 
     * @param dbls double eklenirse
     */
    public abstract void append(double dbls);
    
}
