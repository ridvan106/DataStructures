
import java.util.Random;

/**
 * liste 50 tane raskele sayı ekler ve ekrana hem normal
 * sıralı hemde ters sıralı ekrana yazar
 * @author Rıdvan Demirci 141044070
 */
public class test {
    /** 
    * 10 tane 0-50 arası raskele sayı ekleyip 
    * duz ve ters yazdırma 
    * @param list link liste veri eklemek ici gerekli
    */
    
    public void test1(mySingleLinkedlist list){
         Random a = new Random();
         for (int i = 0; i < 50; i++) {
            list.add(a.nextInt(50));
            
        }
        System.out.println("Sıralı Yazma\n"+list.toString());
        System.out.println("Ters Sıralama\n"+list.reverseToString());
        
        
    }
}
