
import java.util.Iterator;

/**
 * Kendi birinci soruda olusturdugum linked list
 * @author Rıdvan Demirci 141044070
 * @param <E>
 */
public class mySingleLinkedlist<E> {
    /**
     *node olusturma head
     */
    private Node<E> head = null;
    /**
     * size boyutu
     */
    private int size;
     /**
      * reverse için helper
      */
    private String temp="";
    /**
     * recursive fonksyon için helper
     * variable
     */
    private int count = 0;
    /**
     * ilk node ekleme
     * @param item  itemı ilk node a ekleme
     */
    public void addFirst(E item){
        
        head = new Node<E>(item,head);
        size++;
        
    }
    /**
     * Hangi nodden sonra ekleyecegini hesaplar
     * @param nextNode //hangi noddan sonra
     * @param item  //yeni node un itemı
     */
    private void addAfter(Node<E> nextNode,E item){
        nextNode.next = new Node<E>(item,nextNode.next);
        size++;
    }
    /**
     * hangi node dan sonrasını sileceği belirlenir
     * ve o nodu return eder
     * @param node //sonrasının silenecegi node
     * @return      //nodun datası return edilir
     */
    private E removeAfter(Node<E> node){
        Node<E> temp = node.next;
        if(temp != null){
            node.next = temp.next;
            size--;
            return temp.data;
        }
        else{
            return null;
        }
    }
    /**
     * ilk nodu siler head bos degilse head i bir 
     * sonrakinin nexti yapar ve temp null dan farklı ise 
     * onu return eder
     * @return 
     */
    private E removeFirst(){
        Node<E> temp = head;
        if(head != null){
            head = head.next;
        }
        if(temp != null){
            size--;
            return temp.data;
        }else{
            return null;
        }
    }
    /**
     * public yapılacak get methodu için helper method
     * @param index hangi node return edilcek
     * @return secilen node return edilir
     */
    private Node<E> getNode(int index){
        Node<E> node = head;
        for (int i = 0; i < index && node != null; i++) {
            node = node.next;
        }
        return node;
    }
    /**
     * secilen nodun  datasını return eder ve
     * helper method kullanır
     * @param i secilen index
     * @return return datası
     */
    public E get(int i){
        if(i<0 || i>size){
            System.out.print("index out of bounds");
            throw new IndexOutOfBoundsException();
        }
        return getNode(i).data;
    }
    /**
     * Secilen index'in datasına verilen degeri atar
     * @param i verilen index
     * @param val  verilen deger
     */
    public void set(int i,E val){
        if(i<0 || i>=size){
            System.out.print("index out of bounds");
            throw new IndexOutOfBoundsException();
        }
        Node<E> node = getNode(i);
        node.data = val;
    }/**
     *  indis girilmeden ekler
     * @param veri Item
     * @return  true or false
     */
     public boolean add(E veri){
        add(size,veri);
        return true;
        
    }
    /**
     * verilen index a veriyi ekler
     * @param i index degeri
     * @param veri  data
     */
    public void add(int i,E veri){
         if(i<0 || i>size){
            System.out.print("index out of bounds");
            throw new IndexOutOfBoundsException("İndex hatası");
        }
         if(i == 0){
             addFirst(veri);
         }
         else{
             Node<E> temp = getNode(i-1);
             addAfter(temp, veri);
         }
    }
   
    
    /**
     *
     * @return size return eder
     */
   
    public int size(){
        return size;
    }
    
    public Iterator<E> iterator(){
        Iterator<E> itr = new Iterator<E>() {
            int index = 0;
            @Override
            public boolean hasNext() {
                if(index < size){
                    return true;
                }
                return false;
            }

            @Override
            public E next() {
                
               
                E temp = get(index);
                 index++;
                return temp;
                 }
        };
                return itr;
    }
    @Override
    public String toString(){
        String temp = "";
        for (int i = 0; i < size; i++) {
            temp +=  get(i).toString() + "\n";
        }
        return temp;
    }
    /**
     * 
     * @return recursive olarak ters çevrilmiş linked listin
     * degerlerini return eder
     */
    public String reverseToString(){
        if(count == 0){
            temp="";    // ilkkez giriceksek se temp bosaltilir
        }
        if(this.count== this.size){
            count =0;   //base condition count tekrar 0 olur sonraki sıralamalar
                        // icin
            return temp;
        }
        
        temp += get(size-count-1).toString()+"\n";// son nodun datası
        count++;
        return reverseToString(); // tail recursive
        
        
    }
    /**
     * innew class nodu
     * @param <E>  generic tipinde
     */
    private  static class Node<E> {
    private E data;
    private Node<E> next;
    /**
     * constructure
     * @param data  default constructure
     */
    private Node(E data){
        
        this.data = data;
        next = null;
    }
    /**
     * yeni node olusturma
     * @param data verisi
     * @param node nodeun referansı 
     */
    private Node(E data,Node<E> node){
        this.data = data;
        next = node;
    }
          
    
}
    
   
}
