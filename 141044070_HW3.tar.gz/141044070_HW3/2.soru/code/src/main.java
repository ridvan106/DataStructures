/**
 *
 * @author Rıdvan Demirci 141044070
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        mySingleLinkedlist<String> list = new mySingleLinkedlist<>();
        test test1 = new test();
       
       test1.test1(list);
     
    }
    
}
