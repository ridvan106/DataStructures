
import java.io.File;
import java.util.Scanner;

/**
 * Pdf de istenilen test methodu ile çalısır
 * @author Rıdvan Demirci 141044070
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       singleLinkList<Integer> list = new singleLinkList<>();
      
       testFunction test = new testFunction();
       test.addFile100("test.txt");
       test.addFile100("test2.txt");
       try{
           File fp =new File("test.txt");
           Scanner sc = new Scanner(fp);
           while(sc.hasNext()){
               list.add(sc.nextInt());
           }
           for (int i = 0; i < 50; i++) {
               list.remove(0);
           }
           fp =new File("test2.txt");
           sc = new Scanner(fp);
           while(sc.hasNext()){
               list.add(sc.nextInt());
           }
           
       }catch(Exception e){
           
           
       }
       
      
       
       System.out.print("size"+list.size()+"\n");
       System.out.print(list.toString());
       System.out.print("\nSilinenler\n"+list.toStringDeleted());
    }
    
}
