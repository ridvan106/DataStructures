

/**
 * Kendi oluşturdugum linklist classı kitapdan faydalanıldı
 * ve Silinen nodelar ise ayrı bi deletedNode larda tutulur
 * @author Rıdvan Demirci 141044070
 * @param <E>
 */
public class singleLinkList<E> {
    private Node<E> head = null;
    private Node<E> deletedHead = null;
    private int size = 0;
    private int sizeDeleted = 0;
      /**
     * public yapılacak get methodu için helper method
     * @param index hangi node return edilcek
     * @return secilen node return edilir
     */
    private Node<E> getNode(int index){
        Node<E> node = head;
        for (int i = 0; i < index && node != null; i++) {
            node = node.next;
        }
        return node;
    }
    /**
     * belirli indideki nodu set eder
     * @param i verilen indis
     * @param val  Item
     */
    
    public void set(int i,E val){
        if(i<0 || i>=size){
            System.out.print("index out of bounds");
            throw new IndexOutOfBoundsException();
        }
        Node<E> node = getNode(i);
        node.data = val;
    }
     /**
     * verilen index a veriyi eklemeden önce silinmişler 
     * noduna bakar ve veri orada var ise direk oradaki 
     * adresi gösterir
     * @param i index degeri
     * @param veri  data
     */
    public void add(int i,E veri){
         if(i<0 || i>size){
            System.out.print("index out of bounds");
            throw new IndexOutOfBoundsException();
        }else{
             int has = isHas(veri);
            // System.out.println("asda"+has);
            if(has >= 0){   //Silinmişler arasında var ise
                //System.out.println("silinmisler arasında mevcuttur");
                Node <E> temp = getNode(size-1); //en son nodu alır
                Node <E> temp2 = deletedHead;
                int j;
                for ( j = 0; j < has; j++) {
                    temp2 = temp2.next;  // ilgili noda kadar gider
                }
                temp.next = temp2; // en son nodun adresine deletedeki ni ekler
                size ++;
                
                deletedRemove(j); // deleted nodu düzenlenir size-- gibi
            }   // Silinmişler arasında yok ise  ve ilke eklencekse
            else if(i == 0){
             addFirst(veri);
             }
            else{
             Node<E> temp = getNode(i-1);
             addAfter(temp, veri);
         }
         }
    }
    /**
     * verileri sıralı şekilde ekler size kullanılır
     * @param veri gereken Item
     * @return  true or false
     */
    public boolean add(E veri){
        add(size,veri);
        return true;
        
    }
    /**
     * çıkarılması gereken nodun öncesinin adresi bir sonrakini
     * gösterir ve silinmişler nodunu son elemanına eklenir
     * @param i eklenmesi gereken indis
     * @param node  eklenmesi gereken node
     */
    private void addDelete(int i,Node<E> node){
         
         if(i == 0){
            // System.out.print("silinenler"+veri+"\n");
             deletedHead = node; // eger ilk node ise
         }
         else{  // ilk node degil ise size sonuna kadar gider ve oranın 
                // next ine ekler
             Node<E> temp = deletedHead;
             for (int j = 0; j < i-1; j++) {
                 temp = temp.next;  
             }
             temp.next = node; // nodu nextine ekler
             
         }
        
    }
    /**
     * eklenecek olan verinin silinmişler nodunda olup olmadıgına
     * bakar var ise true yok ise false
     * @param data aranan data
     * @return true or false
     */
    private int isHas(E data){
         Node<E> temp = deletedHead;
             for (int j = 0; j < sizeDeleted; j++) {
                 if(temp.data == data){
                     return j; // aranacak data 
                 }
                 temp = temp.next;
             }
             return -1;
    }
    /**
     * kaçtane node oldugu
     * @return 
     */
    public int size(){
        return size;
    }
     /**
     * ilk node ekleme
     * @param item  itemı ilk node a ekleme
     */
    public void addFirst(E item){
        
        head = new Node<E>(item,head);
        size++;
        
    }
    /**
     * Hangi nodden sonra ekleyecegini hesaplar
     * @param nextNode //hangi noddan sonra
     * @param item  //yeni node un itemı
     */
    private void addAfter(Node<E> nextNode,E item){
        nextNode.next = new Node<E>(item,nextNode.next);
        size++;
    }
    /**
     * seçilen nodedan sonrasını siler ve size 1 azaltılır
     * @param node silinmesi gereekn node dan öncesi
     */
    private void removeAfter(Node<E> node){
        Node<E> temp = node.next;
        if(temp != null){
            node.next = temp.next;
            size--;
            
        }
    }
    /**
     * eger ilk node silinecekse
     */
    private void removeFirst(){
        Node<E> temp = head;
        if(head != null){
            head = head.next;
        }
        if(temp != null){
            size--;
        }
    }
    /**
     * silinecek node önce node silinmişler nodeuna gonderilir sonra 
     * öncekinin adresi sonrakini gösterecek şekilde
     * node lar ayarlanır
     * @param indis 
     */
    public void  remove(int indis){
        try{
       if(size == 0){
           System.out.println("size zaten sıfır");
           System.exit(0);
       }
        if(indis != 0){
            addDelete(sizeDeleted, getNode(indis));
            sizeDeleted++;
            removeAfter(getNode(indis-1));
           
        }
        else{
            addDelete(sizeDeleted, getNode(indis));
            sizeDeleted++;
            removeFirst();
           
        }
        }
        catch (Exception e){
            System.out.println("Index hatası Remove ile ilgili \n exception throws");
            System.exit(1);
        }
    }
    
    /**
     * eger eklenecek Item silinmişler node unda var ise
     * oranın adresi gosterilir ve silinmisler nodunun adresleride
     * ona gore ayarlanır
     * @param node 
     */
    private void deletedRemoveAfter(Node<E> node){
         Node<E> temp = node.next;
        //System.out.println("eklenen"+temp.data);
        if(temp != null){
            node.next = temp.next;
            sizeDeleted--;
            
        }
    }
    /**
     * ilk node silinecek ise
     */
    private void deletedRemoveFirst(){
        Node<E> temp = deletedHead;
        if(head != null){
            deletedHead =deletedHead.next;
        }
        if(temp != null){
            sizeDeleted--;
        }
    }
    /**
     * silinmişler nodenundan normal node a veri eklenecekse
     * @param indis  gereken indis
     */
    private void deletedRemove(int indis){
         if(sizeDeleted == 0){
           System.out.println("size zaten sıfır");
           System.exit(0);
       }
         if(indis != 0){
            Node<E> temp =deletedHead;
             for (int i = 0; i < indis-1; i++) {
                 temp = temp.next;
             }
            deletedRemoveAfter(temp);
        }
        else{
            
            deletedRemoveFirst();
           
        }
    }
    
    /**
     * secilen nodun  datasını return eder ve
     * helper method kullanır
     * @param i secilen index
     * @return return datası
     */
    public E get(int i){
        if(i<0 || i>size || size==0){
            System.out.print("index out of bounds\n");
            System.exit(0);
        }
        return getNode(i).data;
    }
    /**
     * deneme amaçlı silinmiş olan node ları listeler
     * @return Stringleri alt alta yazıp listeler
     */
    public String toStringDeleted(){
        String temp="";
        Node <E> tempN = deletedHead;
        for (int i = 0; i < sizeDeleted; i++) {
            
            temp += tempN.data.toString()+"\n";
            tempN = tempN.next;
        }
        return temp;
    }
    /**
     * normal node daki dataları yazar ekrana
     * @return alt alta listeler
     */
    @Override
    public String toString(){
        String temp = "";
        for (int i = 0; i < size; i++) {
            temp +=  get(i).toString() + "\n";
        }
        return temp;
    }
    /**
     * Inner node classı kitaptan yardım alındı
     * @param <E> 
     */
    private  static class Node<E> {
    private E data;
    private Node<E> next;
    /**
     * constructure
     * @param data  default constructure
     */
    private Node(E data){
        
        this.data = data;
        next = null;
    }
    /**
     * yeni node olusturma
     * @param data verisi
     * @param node nodeun referansı 
     */
    private Node(E data,Node<E> node){
        this.data = data;
        next = node;
    }
          
    
}
}
