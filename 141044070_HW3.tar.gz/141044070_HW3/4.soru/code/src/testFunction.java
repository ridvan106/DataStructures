
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Random;


/**
 * bu test classı verilen isimde ki dosyaya
 * 100 tane random sayı alt alta olacak şekilde atar 
 * @author Rıdvan Demirci 141044070
 */
public class testFunction {
    /**
     * 100 tane sayı alt alta yazar
     * @param fileName  dosya adı
     */
    public void addFile100(String fileName){
        try{
        File fp =new File(fileName);
        FileWriter fw = new FileWriter(fp);
        BufferedWriter bf = new BufferedWriter(fw);
        Random num =new Random();
            for (int i = 0; i < 100; i++) {
                int sayi = num.nextInt(50);
                bf.write(sayi+"\n");
            }
            bf.close();
            fw.close();
        
        }catch(Exception E){
            
        }
    }
    
}
