

/**
 * Created by syucer on 4/24/2017.
 */
public class HashTableChaining<K, V> implements HashMap<K, V> {
    /** The table */
    private HashTableOpen<Entry<K, V>>[] table = new HashTableOpen[CAPASITY];
    private static final int CAPASITY = 101;
    private int size = 0;

    public HashTableChaining(){
        for (int i=0;i<CAPASITY;i++)
        table[i] = new HashTableOpen<>();
    }

    //Do not forget you can use more class and methods to do this homework,
    // this project gives you an initial classes an methods to see easily
    //....
    //.... other class members

    @Override
    public V get(Object key) {
        String temp = key.toString(); // gelen veri stringe donusturulur
      //  System.out.println(temp);
        int hash = Math.abs(temp.hashCode());
        // System.out.println(hash);
        hash = hash % CAPASITY;
        //System.out.println(hash);
        return (V) table[hash].get(key,hash);
    }

    @Override
    public V put(K key, V value) {
        String temp = key.toString(); // gelen veri stringe donusturulur
      //  System.out.println(temp);
        int hash = Math.abs(temp.hashCode());
       // System.out.println(hash);
        hash = hash % CAPASITY;
       // System.out.println(hash);
        size ++;
        table[hash].add(key,value,hash);




        return value;



    }

    @Override
    public V remove(Object key) {
        String temp = key.toString(); // gelen veri stringe donusturulur
        //  System.out.println(temp);
        int hash = Math.abs(temp.hashCode());
        // System.out.println(hash);
        hash = hash % CAPASITY;
        size --;
        return (V) table[hash].remove(key,hash);

    }

    @Override
    public int size() {
       return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }
    private static class Entry<K,V> {
        private K key;
        private V value;
        public Entry(K key,V value){
            this.key = key;
            this.value = value;
        }
        public K getKey(){
            return key;
        }
        public V getValue(){
            return value;
        }
        public V setValue(V val){
            V temp = value;
            value = val;
            return temp;
        }

    }
}
