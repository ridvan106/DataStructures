

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by Rıdvan Demirci 141044070
 */
public class HashTableOpen<T> {
    private static final int CAPASITY = 101;
    private int size = 0;
    private ArrayList<LinkedList<T>> [] table = new ArrayList[CAPASITY];
    public HashTableOpen(){
        for (int i=0;i< CAPASITY;i++) {
            table[i] = new ArrayList<>();
        }
    }

    public void add(Object key, Object value,int hash){

            LinkedList<Entry<Object,Object>> temp = new LinkedList<>();
            Entry<Object,Object> tempEntry = new Entry<>(key,value);
            temp.add(tempEntry);
            //System.out.println(temp.getFirst().getValue());
            table[hash].add((LinkedList<T>) temp);
            size++;

    }

    public Object get(Object key,int hash){
        try {
         //   System.out.println(hash);
            LinkedList<Entry<Object, Object>> temp = (LinkedList<Entry<Object, Object>>) table[hash].get(table[hash].size() - 1);
            Object value = temp.getFirst().getValue();
          //  System.out.println(value.toString());
            return value;
        }
        catch (Exception e){
            System.out.println("Beklenmeyen hata Sehir yok");
        }
        return key;
    }
    public Object remove(Object key,int hash) {
        try {
          //  System.out.println(hash);
            LinkedList<Entry<Object, Object>> temp = (LinkedList<Entry<Object, Object>>) table[hash].remove(table[hash].size()-1);
            Object value = temp.getFirst().getValue();
            //System.out.println(value.toString());
            size--;
            return value;
        }
        catch (Exception e){
            System.out.println("Beklenmeyen hata Sehir yok");
        }
        return null;

    }
    public int size(){ return  size;}
    private static class Entry<K,V> {
        private K key;
        private V value;
        public Entry(K key,V value){
            this.key = key;
            this.value = value;
        }
        public K getKey(){
            return key;
        }
        public V getValue(){
            return value;
        }
        public V setValue(V val){
            V temp = value;
            value = val;
            return temp;
        }

    }

}
